package cartillamilitar2.pkg0;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class RegistroCartilla extends javax.swing.JFrame {
    Connection conexion;
    Statement sentencia;
    
    

    public RegistroCartilla() {
        initComponents();
        conectarBaseDatos();
        cargarTitulosColumas();
        cargarDatos();
        
         this.setLocationRelativeTo(this);
        //poner título a la ventana
        this.setTitle("Sistema de consulta y registro para la cartilla militar - Sedena - Menú principal");
        //Escalar imagenes
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel1, "src/Imagenes/Fondo.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel2, "src/Imagenes/aguila-removebg-preview.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel3, "src/Imagenes/user2.png");

    }
    public void conectarBaseDatos() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); //Linea que carga el driver
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar Driver");
        }
        try {
            conexion = DriverManager.getConnection("jdbc:ucanaccess://src\\Bd\\Cartilla.accdb");
            //En esta parte tenemos que cambiar la ruta en la que se encuentra nuestra base de datos 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la dirección de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
        try {
            sentencia = conexion.createStatement();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al crear la conexión con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void cargarTitulosColumas(){
        
    } 
    
    public void cargarDatos() {
        String datos[] = new String[12];    
        String sql = "SELECT Nombre, Ano, Nacido, Padre, Madre, Estadocivil, Ocupacion, Estudios, Domicilio, Zona, matricula, CURP FROM Datos";  
        try {
            ResultSet resultado = sentencia.executeQuery(sql);  
            
            DefaultTableModel modelo1 = (DefaultTableModel) tabla1.getModel();
            int filas1 = modelo1.getRowCount();
            for(int j=0;filas1>j;j++){
                modelo1.removeRow(0);
            }
            
            while (resultado.next()) {                                    
                datos[0] = resultado.getString("Nombre");
                datos[1] = resultado.getString("Ano");
                datos[2] = resultado.getString("Nacido");
                datos[3] = resultado.getString("Padre");
                datos[4] = resultado.getString("Madre");
                datos[5] = resultado.getString("Estadocivil");
                datos[6] = resultado.getString("Ocupacion");
                datos[7] = resultado.getString("Estudios");
                datos[8] = resultado.getString("Domicilio");
                datos[9] = resultado.getString("Zona");
                datos[10] = resultado.getString("matricula");
                datos[11] = resultado.getString("CURP");
                modelo1.addRow(datos);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar los Datos\n" + ex);
        }
    }
    public static boolean validar(String s)
    {
        return s.matches("^[a-zA-ZÁáÉéÍíÓóÚú ]+$");
    }
    public static boolean validarM(String s)
    {
        return s.matches("^[A-Z]-[0-9]{7}$");
    }
    public static boolean validarN(String s)
    {
        return s.matches("[0-9]{4}");
    }
    public static boolean validarC(String s)
    {
        return s.matches("^[A-Z]{4}[0-9]{6}[A-Z]{7}[0-9]{1}$");
    }
    public boolean tV(){
    
        boolean r=true;
        String m=CURP.getText(), d=Matricula.getText(), g=Gestudios.getText(), p=Padre.getText(),p2=Madre.getText();
        if (r) {
        
                if (m.equals("") || p.equals("") || g.equals("") || p2.equals("") || d.equals("")) {
                JOptionPane.showMessageDialog(null, "DEBEN LLENARSE TODOS LOS CAMPOS","AVISO", JOptionPane.INFORMATION_MESSAGE);
                r=false;
            } 
        }
        
        return r;
    }
    public  boolean valida()
    {
      
      boolean b=true;
        if(b==true){
            if (validar(Nombre.getText().trim())) {
                
         
        }
         else{
        
        JOptionPane.showMessageDialog(null, "SOLO SE PERMITEN LETRAS EN EL CAMPO NOMBRE", "ERRROR", JOptionPane.ERROR_MESSAGE);
         b=false;
        }
            
          if (validar(Gestudios.getText().trim())) {
         
        }  
            else{
            JOptionPane.showMessageDialog(null, "SOLO SE PERMITEN LETRAS EN EL CAMPO ESTUDIOS", "ERRROR", JOptionPane.ERROR_MESSAGE);
         b=false;
            }
   
        if (validarC(CURP.getText().trim())) {
         
        }
        else{
        
        JOptionPane.showMessageDialog(null, "CURP INCORRECTA", "ERRROR", JOptionPane.ERROR_MESSAGE);
         b=false;
        }
        if (validar(Padre.getText().trim()) && validar(Madre.getText().trim())) {
         
        }
        else{
        
        JOptionPane.showMessageDialog(null, "SOLO SE PERMITEN LETRAS EN EL CAMPO PADRE/MADRE", "ERRROR", JOptionPane.ERROR_MESSAGE);
        b=false;
        }
        if (validar(Domicilio.getText().replaceAll("\\.", " ").trim()) && validar(Ocupacion.getText().trim())) {
         
        }
        else{
        
        JOptionPane.showMessageDialog(null, "SOLO SE PERMITEN LETRAS EN ESTE CAMPO", "ERRROR", JOptionPane.ERROR_MESSAGE);
         b=false;
        }
         if (validarM(Matricula.getText().trim())) {
                
            }
                else{
                JOptionPane.showMessageDialog(null, "MATRICULA MAL ESCRITA", "ERRROR", JOptionPane.ERROR_MESSAGE);   
                b=false;}
        if (validar(LugardNacimiento.getText().trim())) {
            
               
        }
        else{
        
        JOptionPane.showMessageDialog(null, "SOLO SE PERMITEN LETRAS EN ESTE CAMPO", "ERRROR", JOptionPane.ERROR_MESSAGE);
         b=false;
        }
        if (validarN(AA.getText().trim())) {
             
        }
        else{  JOptionPane.showMessageDialog(null, "SOLO SE PERMITEN NUMEROS EN ESTE CAMPO", "ERRROR", JOptionPane.ERROR_MESSAGE);
        b=false;}    
        }
        return b;
    }
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Registrar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla1 = new javax.swing.JTable();
        CURP = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        Matricula = new javax.swing.JTextField();
        Domicilio = new javax.swing.JTextField();
        ECivil = new javax.swing.JTextField();
        Madre = new javax.swing.JTextField();
        Padre = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Gestudios = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        LugardNacimiento = new javax.swing.JTextField();
        Ocupacion = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        AA = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Nombre = new javax.swing.JTextField();
        Titulo2 = new javax.swing.JLabel();
        Titulo1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Regresar = new javax.swing.JButton();
        Salir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Registrar.setBackground(new java.awt.Color(0, 102, 0));
        Registrar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Registrar.setForeground(new java.awt.Color(255, 255, 255));
        Registrar.setText("Registrar");
        Registrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegistrarActionPerformed(evt);
            }
        });
        getContentPane().add(Registrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 510, 100, 30));

        tabla1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Año de nacimiento", "Lugar de nacimiento", "Padre", "Madre", "Estado Civil", "Ocupacion", "Grado de Estudios", "Domicilio", "Zona", "Matricula", "CURP"
            }
        ));
        jScrollPane1.setViewportView(tabla1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 280, 1070, 200));
        getContentPane().add(CURP, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 170, 160, -1));

        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("CURP:");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 170, -1, -1));
        getContentPane().add(Matricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 180, 160, -1));

        Domicilio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DomicilioActionPerformed(evt);
            }
        });
        getContentPane().add(Domicilio, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 130, 160, -1));

        ECivil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ECivilActionPerformed(evt);
            }
        });
        getContentPane().add(ECivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 170, 150, -1));

        Madre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MadreActionPerformed(evt);
            }
        });
        getContentPane().add(Madre, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 180, -1));

        Padre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PadreActionPerformed(evt);
            }
        });
        getContentPane().add(Padre, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 230, 180, -1));

        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Matrícula: ");
        getContentPane().add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 180, -1, -1));

        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Domicilio:");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, 60, -1));

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Estado civil: ");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Nombre de la Madre:");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 130, 30));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Nombre del Padre:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 230, 110, 20));

        Gestudios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GestudiosActionPerformed(evt);
            }
        });
        getContentPane().add(Gestudios, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 130, 160, -1));

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Grado de estudios:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, -1, -1));
        getContentPane().add(LugardNacimiento, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 90, 150, -1));
        getContentPane().add(Ocupacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 130, 160, 20));

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Ocupación: ");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 130, -1, 20));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Lugar de nacimiento:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 90, 130, 20));
        getContentPane().add(AA, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 90, 160, 20));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Nombre completo:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 120, 20));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Año de nacimiento:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 90, 130, 30));
        getContentPane().add(Nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, 210, -1));

        Titulo2.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo2.setForeground(new java.awt.Color(255, 255, 255));
        Titulo2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo2.setText("Cartilla Militar");
        getContentPane().add(Titulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, -10, 740, 110));

        Titulo1.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo1.setForeground(new java.awt.Color(255, 255, 255));
        Titulo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo1.setText("Registro");
        getContentPane().add(Titulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, 740, 110));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 50, 50));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 330, 50, 50));

        Regresar.setBackground(new java.awt.Color(0, 102, 0));
        Regresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setText("Regresar");
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        getContentPane().add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 530, 100, 30));

        Salir.setBackground(new java.awt.Color(0, 102, 0));
        Salir.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(255, 255, 255));
        Salir.setText("Salir");
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        getContentPane().add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 530, 80, 30));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1100, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        MenuAdmin newframe= new MenuAdmin();
        newframe.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegresarActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SalirActionPerformed

    private void GestudiosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GestudiosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_GestudiosActionPerformed

    private void PadreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PadreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PadreActionPerformed

    private void MadreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MadreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MadreActionPerformed

    private void ECivilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ECivilActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ECivilActionPerformed

    private void DomicilioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DomicilioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DomicilioActionPerformed

    private void RegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegistrarActionPerformed
      
        if (tV()) {
            
        
     if (valida()) {
            
        
    String N = this.Nombre.getText();
    String A = this.AA.getText();
    String L = this.LugardNacimiento.getText();
    String P = this.Padre.getText();
    String M = this.Madre.getText();
    String E = this.ECivil.getText();
    String O = this.Ocupacion.getText();
    String G = this.Gestudios.getText();
    String D = this.Domicilio.getText();
    String MT = this.Matricula.getText(); 
    String CP = this.CURP.getText();
      
    String sql = "insert into Datos(Nombre, Ano, Nacido, Padre, Madre, Estadocivil, Ocupacion, Estudios, Domicilio, matricula, CURP, Zona)values('"+N+"','"+A+"','"+L+"','"+G+"','"+P+"','"+M+"','"+E+"','"+D+"','"+O+"','"+MT+"','"+CP+"', '22/a')";
    
    try{ 
        sentencia.executeUpdate(sql);
        JOptionPane.showMessageDialog(null, "Datos Registrados Correctamente " , "Acceso", JOptionPane.INFORMATION_MESSAGE);
        Nombre.setText("");
        AA.setText("");
        LugardNacimiento.setText("");
        Gestudios.setText("");
        Padre.setText("");
        Madre.setText("");
        ECivil.setText("");
        Domicilio.setText("");
        Ocupacion.setText("");
        CURP.setText("");
        Matricula.setText("");
    } catch (SQLException ex){
        JOptionPane.showMessageDialog(null,"Error, sus datos no fueron ingresados\n"+ex);
    }
    cargarDatos();
        }
        else{
        RegistroCartilla newframe= new RegistroCartilla();
        newframe.setVisible(true);
        this.dispose();
        }
      }
        else{
        RegistroCartilla newframe= new RegistroCartilla();
        newframe.setVisible(true);
        this.dispose();
        }
    }//GEN-LAST:event_RegistrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroCartilla.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroCartilla().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField AA;
    private javax.swing.JTextField CURP;
    private javax.swing.JTextField Domicilio;
    private javax.swing.JTextField ECivil;
    private javax.swing.JTextField Gestudios;
    private javax.swing.JTextField LugardNacimiento;
    private javax.swing.JTextField Madre;
    private javax.swing.JTextField Matricula;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField Ocupacion;
    private javax.swing.JTextField Padre;
    private javax.swing.JButton Registrar;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel Titulo1;
    private javax.swing.JLabel Titulo2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla1;
    // End of variables declaration//GEN-END:variables
}
