package cartillamilitar2.pkg0;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author david
 */
public class AccesoPostulante extends javax.swing.JFrame {
    Connection conexion;
    Statement sentencia;
    /**
     * Creates new form AccesoPostulante
     */
    public AccesoPostulante() {
        initComponents();
        conectarBaseDatos();
        //centrar ventana
        this.setLocationRelativeTo(this);
        //poner título a la ventana
        this.setTitle("Sistema de consulta y registro para la cartilla militar - Sedena - Acceso a postulantes");
        //Escalar imagenes
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel1, "src/Imagenes/Fondo.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel2, "src/Imagenes/aguila-removebg-preview.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel3, "src/Imagenes/user2.png");
    }
    
    public void conectarBaseDatos() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); //Linea que carga el driver
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar Driver");
        }
        try {
            conexion = DriverManager.getConnection("jdbc:ucanaccess://src\\Bd\\Cartilla.accdb");
            //En esta parte tenemos que cambiar la ruta en la que se encuentra nuestra base de datos 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la dirección de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
        try {
            sentencia = conexion.createStatement();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al crear la conexión con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Nombre1 = new javax.swing.JLabel();
        Titulo = new javax.swing.JLabel();
        Titulo2 = new javax.swing.JLabel();
        Matricula = new javax.swing.JTextField();
        Ingresar = new javax.swing.JButton();
        Regresar = new javax.swing.JButton();
        Titulo1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Salir = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(740, 380));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Nombre1.setFont(new java.awt.Font("Yu Gothic", 1, 14)); // NOI18N
        Nombre1.setForeground(new java.awt.Color(255, 255, 255));
        Nombre1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Nombre1.setText("Por favor, coloque su Matricula para buscar su información ");
        getContentPane().add(Nombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 170, 520, 40));

        Titulo.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("Ingreso");
        getContentPane().add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 460, 40));

        Titulo2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Titulo2.setForeground(new java.awt.Color(255, 255, 255));
        Titulo2.setText("Matricula");
        getContentPane().add(Titulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 190, 20));

        Matricula.setName(""); // NOI18N
        Matricula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MatriculaActionPerformed(evt);
            }
        });
        getContentPane().add(Matricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 240, 20));

        Ingresar.setBackground(new java.awt.Color(0, 102, 0));
        Ingresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Ingresar.setForeground(new java.awt.Color(255, 255, 255));
        Ingresar.setText("Ingresar");
        Ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresarActionPerformed(evt);
            }
        });
        getContentPane().add(Ingresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 120, 30));

        Regresar.setBackground(new java.awt.Color(0, 102, 0));
        Regresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setText("Regresar");
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        getContentPane().add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 290, 120, 30));

        Titulo1.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo1.setForeground(new java.awt.Color(255, 255, 255));
        Titulo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo1.setText("Cartilla Militar");
        getContentPane().add(Titulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 100));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 90, 80));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 140, 240, 240));

        Salir.setBackground(new java.awt.Color(0, 102, 0));
        Salir.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(255, 255, 255));
        Salir.setText("Salir");
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        getContentPane().add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 290, 140, 30));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresarActionPerformed
        String mat = this.Matricula.getText();
        if(mat.equals("")){
            JOptionPane.showMessageDialog(null, "El campo matricula no puede estar vacio", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
            String sql = "select matricula, Nombre from Datos where matricula = '" + mat +"'"; 
            int contador = 0;
            String Nombre = "";
            try {
                ResultSet resultado = sentencia.executeQuery(sql);  //Linea que ejecuta la consulta sql y almacena los datos en resultado
                while (resultado.next()) {                                    //Bucle que recorre la consulta obtenida
                    contador++;
                    Nombre = resultado.getString("Nombre");
                    Busqueda1 newframe= new Busqueda1();
                    newframe.setVisible(true);
                    this.dispose();
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al cargar los Datos\n" + ex);
            }
            if(contador > 0){
                JOptionPane.showMessageDialog(null, "Bienvenido: " + Nombre, "Acceso", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(null, "El valor dentro del campo matricula no se encuentra dentro de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
        
    }//GEN-LAST:event_IngresarActionPerformed

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        MenuPrincipal newframe= new MenuPrincipal();
        newframe.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegresarActionPerformed

    private void MatriculaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MatriculaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MatriculaActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try {
            sentencia.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la base de datos" + e);
        }
    }//GEN-LAST:event_formWindowClosing

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SalirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccesoPostulante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccesoPostulante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccesoPostulante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccesoPostulante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccesoPostulante().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ingresar;
    private javax.swing.JTextField Matricula;
    private javax.swing.JLabel Nombre1;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel Titulo1;
    private javax.swing.JLabel Titulo2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
