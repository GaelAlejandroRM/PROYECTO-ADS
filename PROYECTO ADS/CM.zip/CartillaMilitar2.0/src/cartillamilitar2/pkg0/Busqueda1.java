package cartillamilitar2.pkg0;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

public class Busqueda1 extends javax.swing.JFrame {
    Connection conexion;
    Statement sentencia;
    String sql;
    int bus=0;
    
    public Busqueda1() {
        initComponents();
        conectarBaseDatos();
        //centrar ventana
        this.setLocationRelativeTo(this);
        //poner título a la ventana
        this.setTitle("Sistema de consulta y registro para la cartilla militar - Sedena - Acceso a postulantes");
        //Escalar imagenes
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel1, "src/Imagenes/Fondo.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel2, "src/Imagenes/aguila-removebg-preview.png");
    }
    
    public void conectarBaseDatos() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); //Linea que carga el driver
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar Dirver");
        }
        try {
            conexion = DriverManager.getConnection("jdbc:ucanaccess://src\\Bd\\Cartilla.accdb");
            //En esta parte tenemos que cambiar la ruta en la que se encuentra nuestra base de datos 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la dirección de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
        try {
            sentencia = conexion.createStatement();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al crear la conexión con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Buscar = new javax.swing.JButton();
        Titulo = new javax.swing.JLabel();
        Nombre1 = new javax.swing.JLabel();
        Regresar1 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        TBusqueda = new javax.swing.JTextField();
        nombre = new javax.swing.JTextField();
        Tnl = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Tano = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        Tnacido = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Bborrar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        Tpadre = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        Tmadre = new javax.swing.JTextField();
        Testadocivil = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        Tocupacion = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        Testudios = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        Tdomicilio = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        Tzona = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        Tmatricula = new javax.swing.JTextField();
        Tcurp = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        Salir1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Titulo1.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo1.setForeground(new java.awt.Color(255, 255, 255));
        Titulo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo1.setText("Cartilla Militar");
        getContentPane().add(Titulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -20, 740, 110));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 80, 70));

        Buscar.setBackground(new java.awt.Color(0, 102, 0));
        Buscar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Buscar.setForeground(new java.awt.Color(255, 255, 255));
        Buscar.setText("Buscar");
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });
        getContentPane().add(Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 100, 120, 30));

        Titulo.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("Busqueda");
        getContentPane().add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 740, 40));

        Nombre1.setFont(new java.awt.Font("Yu Gothic", 1, 14)); // NOI18N
        Nombre1.setForeground(new java.awt.Color(255, 255, 255));
        Nombre1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Nombre1.setText("Seleccione el tipo de busqueda a realizar");
        getContentPane().add(Nombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 70, 740, 40));

        Regresar1.setBackground(new java.awt.Color(0, 102, 0));
        Regresar1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Regresar1.setForeground(new java.awt.Color(255, 255, 255));
        Regresar1.setText("Regresar");
        Regresar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Regresar1ActionPerformed(evt);
            }
        });
        getContentPane().add(Regresar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 270, 130, 30));

        jRadioButton1.setText("Por CURP");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, -1, -1));

        jRadioButton2.setText("Por matricula");
        jRadioButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jRadioButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, -1, -1));

        TBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TBusquedaActionPerformed(evt);
            }
        });
        getContentPane().add(TBusqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 110, 330, 20));
        getContentPane().add(nombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 180, 210, 20));

        Tnl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TnlActionPerformed(evt);
            }
        });
        getContentPane().add(Tnl, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 140, 50, 30));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombre:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 60, 20));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("NL:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 30, 30));
        getContentPane().add(Tano, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 210, 160, 30));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Año de nacimiento:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, 130, 30));
        getContentPane().add(Tnacido, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, 150, 20));

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Lugar de nacimiento:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 130, 20));

        Bborrar.setBackground(new java.awt.Color(0, 102, 0));
        Bborrar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Bborrar.setForeground(new java.awt.Color(255, 255, 255));
        Bborrar.setText("Borrar");
        Bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BborrarActionPerformed(evt);
            }
        });
        getContentPane().add(Bborrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 140, 120, 30));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Padre:");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 150, 40, 20));

        Tpadre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TpadreActionPerformed(evt);
            }
        });
        getContentPane().add(Tpadre, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 150, 180, -1));

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Madre:");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 170, 50, 30));

        Tmadre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TmadreActionPerformed(evt);
            }
        });
        getContentPane().add(Tmadre, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 180, 180, -1));

        Testadocivil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TestadocivilActionPerformed(evt);
            }
        });
        getContentPane().add(Testadocivil, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 210, 170, -1));

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Estado civil: ");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 210, -1, -1));

        Tocupacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TocupacionActionPerformed(evt);
            }
        });
        getContentPane().add(Tocupacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 200, -1));

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Ocupación: ");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        Testudios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TestudiosActionPerformed(evt);
            }
        });
        getContentPane().add(Testudios, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 170, -1));

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Domicilio:");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 240, 60, -1));

        Tdomicilio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TdomicilioActionPerformed(evt);
            }
        });
        getContentPane().add(Tdomicilio, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 240, 170, -1));

        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Zona: ");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 270, -1, -1));
        getContentPane().add(Tzona, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 270, 200, -1));

        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Matrícula: ");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 310, -1, -1));
        getContentPane().add(Tmatricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 310, 180, -1));
        getContentPane().add(Tcurp, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 340, 200, -1));

        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("CURP:");
        getContentPane().add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 340, -1, -1));

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Grado de estudios:");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, -1, -1));

        Salir1.setBackground(new java.awt.Color(0, 102, 0));
        Salir1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Salir1.setForeground(new java.awt.Color(255, 255, 255));
        Salir1.setText("Salir");
        Salir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Salir1ActionPerformed(evt);
            }
        });
        getContentPane().add(Salir1, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 320, 130, -1));
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 740, 390));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        if(bus==1){
            sql = "select NL, Nombre, Ano, Nacido, Padre, Madre, Estadocivil, Ocupacion, Estudios, Domicilio, Zona, matricula, CURP from Datos where CURP = '" + TBusqueda.getText() +"'";
        }else{
            sql = "select NL, Nombre, Ano, Nacido, Padre, Madre, Estadocivil, Ocupacion, Estudios, Domicilio, Zona, matricula, CURP from Datos where matricula = '" + TBusqueda.getText() +"'";
        }
        if(sql.equals("")){
            JOptionPane.showMessageDialog(null, "El campo de busqueda no puede estar vacio", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
            int contador = 0;
            String Nombre = "";
            try {
                ResultSet resultado = sentencia.executeQuery(sql);  //Linea que ejecuta la consulta sql y almacena los datos en resultado
                while (resultado.next()) {                                    //Bucle que recorre la consulta obtenida
                    contador++;
                    nombre.setText(resultado.getString("Nombre"));
                    Tnl.setText(resultado.getString("NL"));
                    Tano.setText(resultado.getString("Ano"));
                    Tnacido.setText(resultado.getString("Nacido"));
                    Tpadre.setText(resultado.getString("Padre"));
                    Tmadre.setText(resultado.getString("Madre"));
                    Testadocivil.setText(resultado.getString("Estadocivil"));
                    Tocupacion.setText(resultado.getString("Ocupacion"));
                    Testudios.setText(resultado.getString("Estudios"));
                    Tdomicilio.setText(resultado.getString("Domicilio"));
                    Tzona.setText(resultado.getString("Zona"));
                    Tmatricula.setText(resultado.getString("matricula"));
                    Tcurp.setText(resultado.getString("CURP"));
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Error al cargar los Datos\n" + ex);
            }
            if(contador > 0){
                JOptionPane.showMessageDialog(null, "Datos obtenidos correctamente", "Acceso", JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(null, "El valor dentro del campo no se encuentra dentro de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

    }//GEN-LAST:event_BuscarActionPerformed

    private void Regresar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Regresar1ActionPerformed
        AccesoPostulante newframe= new AccesoPostulante();
        newframe.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Regresar1ActionPerformed

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        bus=1;
        jRadioButton2.setSelected(false);
        nombre.setText("");
        TBusqueda.setText("");
        Tnl.setText("");
        Tano.setText("");
        Tnacido.setText("");
        Tpadre.setText("");
        Tmadre.setText("");
        Testadocivil.setText("");
        Tocupacion.setText("");
        Testudios.setText("");
        Tdomicilio.setText("");
        Tzona.setText("");
        Tmatricula.setText("");
        Tcurp.setText("");
        
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jRadioButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton2ActionPerformed
        bus=2;
        jRadioButton1.setSelected(false);
        nombre.setText("");
        TBusqueda.setText("");
        Tnl.setText("");
        Tano.setText("");
        Tnacido.setText("");
        Tpadre.setText("");
        Tmadre.setText("");
        Testadocivil.setText("");
        Tocupacion.setText("");
        Testudios.setText("");
        Tdomicilio.setText("");
        Tzona.setText("");
        Tmatricula.setText("");
        Tcurp.setText("");
    }//GEN-LAST:event_jRadioButton2ActionPerformed

    private void TBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TBusquedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TBusquedaActionPerformed

    private void TnlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TnlActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TnlActionPerformed

    private void BborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BborrarActionPerformed
        nombre.setText("");
        TBusqueda.setText("");
        Tnl.setText("");
        Tano.setText("");
        Tnacido.setText("");
        Tpadre.setText("");
        Tmadre.setText("");
        Testadocivil.setText("");
        Tocupacion.setText("");
        Testudios.setText("");
        Tdomicilio.setText("");
        Tzona.setText("");
        Tmatricula.setText("");
        Tcurp.setText("");
    }//GEN-LAST:event_BborrarActionPerformed

    private void TpadreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TpadreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TpadreActionPerformed

    private void TmadreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TmadreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TmadreActionPerformed

    private void TestadocivilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TestadocivilActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TestadocivilActionPerformed

    private void TocupacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TocupacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TocupacionActionPerformed

    private void TestudiosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TestudiosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TestudiosActionPerformed

    private void TdomicilioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TdomicilioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TdomicilioActionPerformed

    private void Salir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Salir1ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_Salir1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Busqueda1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Busqueda1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Busqueda1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Busqueda1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Busqueda1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Bborrar;
    private javax.swing.JButton Buscar;
    private javax.swing.JLabel Nombre1;
    private javax.swing.JButton Regresar1;
    private javax.swing.JButton Salir1;
    private javax.swing.JTextField TBusqueda;
    private javax.swing.JTextField Tano;
    private javax.swing.JTextField Tcurp;
    private javax.swing.JTextField Tdomicilio;
    private javax.swing.JTextField Testadocivil;
    private javax.swing.JTextField Testudios;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel Titulo1;
    private javax.swing.JTextField Tmadre;
    private javax.swing.JTextField Tmatricula;
    private javax.swing.JTextField Tnacido;
    private javax.swing.JTextField Tnl;
    private javax.swing.JTextField Tocupacion;
    private javax.swing.JTextField Tpadre;
    private javax.swing.JTextField Tzona;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JTextField nombre;
    // End of variables declaration//GEN-END:variables
}
