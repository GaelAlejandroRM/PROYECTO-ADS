package cartillamilitar2.pkg0;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
public class AccesoAdministrador extends javax.swing.JFrame {
    Connection conexion;
    Statement sentencia;
    
    public AccesoAdministrador() {
        initComponents();
        //centrar ventana
        conectarBaseDatos();
        this.setLocationRelativeTo(this);
        //poner título a la ventana
        this.setTitle("Sistema de consulta y registro para la cartilla militar - Sedena - Menú principal");
        //Escalar imagenes
        rsscalelabel.RSScaleLabel.setScaleLabel(Jlabel5, "src/Imagenes/Fondo.jpg");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel2, "src/Imagenes/aguila-removebg-preview.png");
        rsscalelabel.RSScaleLabel.setScaleLabel(jLabel3, "src/Imagenes/user2.png");
    }
    public void conectarBaseDatos() {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); //Linea que carga el driver
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error al cargar Driver");
        }
        try {
            conexion = DriverManager.getConnection("jdbc:ucanaccess://src\\Bd\\Cartilla.accdb");
            //En esta parte tenemos que cambiar la ruta en la que se encuentra nuestra base de datos 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error en la dirección de la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
        try {
            sentencia = conexion.createStatement();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al crear la conexión con la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Titulo1 = new javax.swing.JLabel();
        Titulo = new javax.swing.JLabel();
        Nombre1 = new javax.swing.JLabel();
        Titulo2 = new javax.swing.JLabel();
        Tidadmin = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        Ingresar = new javax.swing.JButton();
        Regresar = new javax.swing.JButton();
        Salir = new javax.swing.JButton();
        Tcontadmin = new javax.swing.JPasswordField();
        Jlabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 80, 80));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 230, 130, 150));

        Titulo1.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo1.setForeground(new java.awt.Color(255, 255, 255));
        Titulo1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo1.setText("Cartilla Militar");
        getContentPane().add(Titulo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 100));

        Titulo.setFont(new java.awt.Font("Yu Gothic Light", 1, 24)); // NOI18N
        Titulo.setForeground(new java.awt.Color(255, 255, 255));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Titulo.setText("Ingreso");
        getContentPane().add(Titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, 460, 40));

        Nombre1.setFont(new java.awt.Font("Yu Gothic", 1, 14)); // NOI18N
        Nombre1.setForeground(new java.awt.Color(255, 255, 255));
        Nombre1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Nombre1.setText("Por favor, coloque su ID y Contraseña ");
        getContentPane().add(Nombre1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 520, 40));

        Titulo2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Titulo2.setForeground(new java.awt.Color(255, 255, 255));
        Titulo2.setText("ID:");
        getContentPane().add(Titulo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 190, 40, 20));

        Tidadmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TidadminActionPerformed(evt);
            }
        });
        getContentPane().add(Tidadmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, 260, -1));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Contraseña: ");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 220, 80, 30));

        Ingresar.setBackground(new java.awt.Color(0, 102, 0));
        Ingresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Ingresar.setForeground(new java.awt.Color(255, 255, 255));
        Ingresar.setText("Ingresar");
        Ingresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresarActionPerformed(evt);
            }
        });
        getContentPane().add(Ingresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 120, 30));

        Regresar.setBackground(new java.awt.Color(0, 102, 0));
        Regresar.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Regresar.setForeground(new java.awt.Color(255, 255, 255));
        Regresar.setText("Regresar");
        Regresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegresarActionPerformed(evt);
            }
        });
        getContentPane().add(Regresar, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 310, 120, 30));

        Salir.setBackground(new java.awt.Color(0, 102, 0));
        Salir.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(255, 255, 255));
        Salir.setText("Salir");
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        getContentPane().add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 310, 140, 30));
        getContentPane().add(Tcontadmin, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 230, 250, -1));
        getContentPane().add(Jlabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 380));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void IngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresarActionPerformed
        String mat = this.Tidadmin.getText();
        if(mat.equals("")){
            JOptionPane.showMessageDialog(null, "El campo ID no puede estar vacio", "Error", JOptionPane.ERROR_MESSAGE);
        }else{
            String sql = "select idadmi, Nomautoriza, PASSWORD from administrativo where idadmi = '" + mat +"'"; 
            int contador = 0;
            String Nomautoriza = "";
            String PASSWORD = "";
            try {
                ResultSet resultado = sentencia.executeQuery(sql);  //Linea que ejecuta la consulta sql y almacena los datos en resultado
                while (resultado.next()) {                                    //Bucle que recorre la consulta obtenida
                    contador++;
                    Nomautoriza = resultado.getString("Nomautoriza");
                    PASSWORD = resultado.getString("PASSWORD");
                }
                if (Tcontadmin.getText().equals("")){
                    JOptionPane.showMessageDialog(null, "El campo contraseña no puede estar vacío.");
                }else {
                    if(Tcontadmin.getText().equals(PASSWORD)){
                    MenuAdmin newframe= new MenuAdmin();
                    newframe.setVisible(true);
                    this.dispose();
                    if(contador > 0){
                        JOptionPane.showMessageDialog(null, "Bienvenido Adiminstrador ", "Acceso", JOptionPane.INFORMATION_MESSAGE);
                    }
                    }else{
                        JOptionPane.showMessageDialog(null, "La contraseña es incorrecta ", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                } catch (SQLException ex) {
                   JOptionPane.showMessageDialog(null, "Error al cargar los Datos\n" + ex);
            }
            
        }
        
    }//GEN-LAST:event_IngresarActionPerformed

    private void RegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegresarActionPerformed
        MenuPrincipal newframe= new MenuPrincipal();
        newframe.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_RegresarActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_SalirActionPerformed

    private void TidadminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TidadminActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TidadminActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AccesoAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AccesoAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AccesoAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AccesoAdministrador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AccesoAdministrador().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Ingresar;
    private javax.swing.JLabel Jlabel5;
    private javax.swing.JLabel Nombre1;
    private javax.swing.JButton Regresar;
    private javax.swing.JButton Salir;
    private javax.swing.JPasswordField Tcontadmin;
    private javax.swing.JTextField Tidadmin;
    private javax.swing.JLabel Titulo;
    private javax.swing.JLabel Titulo1;
    private javax.swing.JLabel Titulo2;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
