/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cartillamilitar2.pkg0;

/**
 *
 * @author david
 */
public class CartillaMilitar20 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Acceso c=new Acceso();
        c.setBounds(0, 0, 740, 380);
        c.setLocationRelativeTo(null);
        c.setVisible(true);
    }
    
}
